<?php
//ThinkPHP系统目录定义
define('THINK_PATH', '../../ThinkPHP');
define('APP_PATH','../');
// 数据库连接信息
$config =   array(
    'DB_TYPE'=>'mysql',
    'DB_HOST'=>'localhost',
    'DB_NAME'=>'test',
    'DB_USER'=>'root',
    'DB_PWD'=>'',
    'DB_PORT'=>'3306',
    'DB_PREFIX'=>'think_',
)

?>